import os
import pandas as pd
from collections import defaultdict

# Folder containing all the CSVs
DATA_FOLDER = 'temperature_data'

# Map month index (0 = Jan) to seasons
def get_season(month_index):
    if month_index in [11, 0, 1]:  # Dec, Jan, Feb
        return 'Summer'
    elif month_index in [2, 3, 4]:  # Mar, Apr, May
        return 'Autumn'
    elif month_index in [5, 6, 7]:  # Jun, Jul, Aug
        return 'Winter'
    elif month_index in [8, 9, 10]:  # Sep, Oct, Nov
        return 'Spring'

# Structures to store data
seasonal_all = defaultdict(list)  # season -> [temps from all stations and years]
station_all_temps = defaultdict(list)  # station -> [all monthly temps]
station_max_temp = defaultdict(lambda: float('-inf'))
station_min_temp = defaultdict(lambda: float('inf'))

# Process each CSV file
for filename in os.listdir(DATA_FOLDER):
    if filename.endswith('.csv') and filename.startswith("stations_group_"):
        filepath = os.path.join(DATA_FOLDER, filename)
        df = pd.read_csv(filepath)
        df.columns = df.columns.str.strip()  # Clean column names

        for _, row in df.iterrows():
            try:
                station = str(row['STATION_NAME']).strip()
                monthly = [float(row[col]) for col in df.columns[4:16]]

                for i, temp in enumerate(monthly):
                    season = get_season(i)
                    seasonal_all[season].append(temp)
                    station_all_temps[station].append(temp)
                    station_max_temp[station] = max(station_max_temp[station], temp)
                    station_min_temp[station] = min(station_min_temp[station], temp)

            except Exception:
                continue  # Skip malformed rows

# 1. Average temperatures for each season (overall, not per station)
with open("average_temp.txt", "w") as f:
    for season in ['Summer', 'Autumn', 'Winter', 'Spring']:
        temps = seasonal_all[season]
        if temps:
            avg = sum(temps) / len(temps)
            f.write(f"{season}: {avg:.2f}°C\n")

# 2. Station(s) with the largest temperature range
station_ranges = {
    s: station_max_temp[s] - station_min_temp[s]
    for s in station_max_temp
}
max_range = max(station_ranges.values())
largest_range_stations = [s for s, r in station_ranges.items() if r == max_range]

with open("largest_temp_range_station.txt", "w") as f:
    f.write(f"Largest temperature range: {max_range:.2f}°C\n")
    for s in largest_range_stations:
        f.write(f"{s}\n")

# 3. Warmest and Coolest station(s) by overall average temperature
avg_station_temps = {
    s: sum(temps) / len(temps)
    for s, temps in station_all_temps.items()
}

max_avg = max(avg_station_temps.values())
min_avg = min(avg_station_temps.values())
warmest = [s for s, t in avg_station_temps.items() if t == max_avg]
coolest = [s for s, t in avg_station_temps.items() if t == min_avg]

with open("warmest_and_coolest_station.txt", "w") as f:
    f.write(f"Warmest Station(s) - Avg Temp: {max_avg:.2f}°C\n")
    for s in warmest:
        f.write(f"{s}\n")
    f.write(f"\nCoolest Station(s) - Avg Temp: {min_avg:.2f}°C\n")
    for s in coolest:
        f.write(f"{s}\n")
